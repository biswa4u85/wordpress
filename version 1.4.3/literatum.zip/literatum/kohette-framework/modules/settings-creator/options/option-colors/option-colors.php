<?php
/**
 * 'colors' option
 *
 *
 */


function KTT_colors_field($te) {

  ?>

  <?php
}
add_action('KTT_settings_option_field', 'KTT_colors_field', 2, 1);
