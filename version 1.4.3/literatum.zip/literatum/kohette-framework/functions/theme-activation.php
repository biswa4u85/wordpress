<?php
/**
 * theme activation hook
 *
 */




/*
function my_activation_settings($theme)
{


	print_r($theme);

    if ( 'Your Theme Name' == $theme )
    {
        // do something
    }
    return;
}
add_action('switch_theme', 'my_activation_settings');
*/