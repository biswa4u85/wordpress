<?php
/**
 * The template for displaying Archive pages.
 *
 *
 */


include('category.php');
