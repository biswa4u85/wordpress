<?php
/**
 * Featured images for categories
 *
 */

if (is_admin()) include('featured-image-upload-input.php');