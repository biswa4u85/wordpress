<?php
/**
 * Featured images for categories
 *
 */

if (is_admin()) include('template-admin-select.php');